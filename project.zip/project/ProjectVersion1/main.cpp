#include <iostream>

using namespace std;

int main(){

    int option;
    cout<<"Enter 1 for conversion of weight from kilograms to pounds "<<endl;
    cout<<"Enter 2 for conversion of  weight from pounds to kilograms "<<endl;
    cout<<"Enter 3 to quit the application "<<endl;
    cin>>option;

    switch(option){
        case 1:{
            double pounds,kg;
            double maximum=0,minimum=999,total=0,average=0;
            int i=1,counter;
            do{

                cout<<endl;
                cout<<"Enter weight "<<i<<" in kilograms :";
                cin>>pounds;
                if(pounds>0){
                   kg=pounds/2.2046;
                   cout<<"\nThe conversion of weight "<<i<<" from kilograms"<<pounds <<" to pounds is : "<<kg;
                   cout<<endl;
                }
                else{
                    break;
                }
                total+=pounds;
                i++;
                counter++;
                if(maximum<pounds){
                maximum=pounds;
                }
                if(minimum>pounds){
                    minimum=pounds;
                }
            }while(i<=15);
            average=total/counter;
            cout<<"\nThe maximum of weights you entered is: "<<maximum<<endl;
            cout<<"The minimum of weights you entered is: "<<minimum<<endl;
            cout<<"The average of the weights you entered is: "<<average<<endl;
            break;
        }
        case 2:{
            int pounds1,kilogram;
            int maximum1,minimum1,total1,average1;
            double x=1,counter1;
            do{

                cout<<"\n";
                cout<<"Enter weight "<<x<<" in pounds :";
                cin>>kilogram;
                if(maximum1<kilogram){
                maximum1=kilogram;
                }
                if(minimum1>kilogram){
                    minimum1=kilogram;
                }
                if(kilogram>0){
                   pounds1=kilogram*2.204623;
                   cout<<"\nThe conversion of weight "<<x<<" from pounds"<<kilogram <<" to kilograms is : "<<kilograms1<<endl;
                   cout<<endl;
                }
                else{
                    break;
                }
                total1+=kilogram;
                x++;
                counter1++;
            }while(x<=15);
            average1=total1/counter1;
            cout<<"\nThe maximum of weights you entered is: "<<maximum1<<endl;
            cout<<"The minimum of weights you entered is: "<<minimum1<<endl;
            cout<<"The average of the weights you entered is: "<<average1<<endl;
            break;
        }
        case 3:
            {
                cout<<"Now we are quitting the application"<<endl;
                break;
            }
        default:
            cout<<"Now we are ending the weight conversion program!!"<<endl;
            break;
    }
    cout<<endl;
    cout<<"\nNow we are ending the weight conversion program!!"<<endl;
    return 0;
}

